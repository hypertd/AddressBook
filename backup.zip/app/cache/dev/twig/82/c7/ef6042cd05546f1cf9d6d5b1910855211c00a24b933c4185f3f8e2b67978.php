<?php

/* HypertdAddressbookBundle:Addressbook:index.html.twig */
class __TwigTemplate_82c7ef6042cd05546f1cf9d6d5b1910855211c00a24b933c4185f3f8e2b67978 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("HypertdAddressbookBundle:Base:base.html.twig");

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "HypertdAddressbookBundle:Base:base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        echo "Index";
    }

    // line 5
    public function block_head($context, array $blocks = array())
    {
        // line 6
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
    }

    // line 10
    public function block_content($context, array $blocks = array())
    {
        // line 11
        echo "    <h1>Address book</h1>
    Filter: <input type=\"text\" id='myfilter' />
    <div id=\"layout\" style=\"padding:10px\">
        <ui:ui>
          <ui:rows>
             <ui:toolbar height=\"40\" padding=\"10\" width=\"100%\">
                    <ui:cols>
                        <ui:button id=\"addBtn\" css=\"crudBtn\" type=\"imageButton\" width=\"90\" label=\"add\" image=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/hypertdaddressbook/images/icons/icon_add.png"), "html", null, true);
        echo "\"></ui:button>
                        <ui:button id=\"editBtn\" css=\"crudBtn\" type=\"imageButton\" width=\"90\" label=\"update\" image=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/hypertdaddressbook/images/icons/icon_edit.png"), "html", null, true);
        echo "\"></ui:button>
                        <ui:button id=\"deleteBtn\" css=\"crudBtn\" type=\"imageButton\" width=\"90\" label=\"delete\" image=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('assets')->getAssetUrl("bundles/hypertdaddressbook/images/icons/icon_delete.png"), "html", null, true);
        echo "\"></ui:button>
                    </ui:cols>
            </ui:toolbar>
               <ui:datatable id=\"contactTable\" autowidth=\"true\" autoheight=\"true\" url=\"/addressbook/contact\" datatype=\"xml\" select=\"row\" width=\"100%\">
                    <ui:column id=\"id\" header=\"\" sort=\"int\"></ui:column>
                    <ui:column id=\"firstname\" header=\"First Name\" sort=\"string\"></ui:column>
                    <ui:column id=\"lastname\" header=\"Last Name\" sort=\"string\"></ui:column>
                    <ui:column id=\"address_1\" header=\"Address 1\" sort=\"string\"></ui:column>
                    <ui:column id=\"address_2\" header=\"Address 2\" sort=\"string\"></ui:column>
                    <ui:column id=\"city\" header=\"City\" sort=\"string\"></ui:column>
                    <ui:column id=\"postal\" header=\"Postal\" sort=\"string\"></ui:column>
                    <ui:column id=\"tel_home\" header=\"Home Tel\" sort=\"integer\"></ui:column>
                    <ui:column id=\"tel_mobile\" header=\"Mobile Tel\" sort=\"integet\"></ui:column>
               </ui:datatable>
          </ui:rows>
        </ui:ui>
    </div>
";
    }

    public function getTemplateName()
    {
        return "HypertdAddressbookBundle:Addressbook:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  66 => 20,  62 => 19,  58 => 18,  49 => 11,  46 => 10,  39 => 6,  36 => 5,  30 => 3,);
    }
}
