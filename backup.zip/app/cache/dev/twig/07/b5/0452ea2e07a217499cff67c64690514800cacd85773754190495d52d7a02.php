<?php

/* HypertdAddressbookBundle:Base:base.html.twig */
class __TwigTemplate_07b50452ea2e07a217499cff67c64690514800cacd85773754190495d52d7a02 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
            'footer' => array($this, 'block_footer'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        ";
        // line 4
        $this->displayBlock('head', $context, $blocks);
        // line 20
        echo "    </head>
    <body>
        ";
        // line 22
        $this->displayBlock('content', $context, $blocks);
        // line 23
        echo "        <div id=\"footer\">
            ";
        // line 24
        $this->displayBlock('footer', $context, $blocks);
        // line 27
        echo "        </div>
    </body>
</html>";
    }

    // line 4
    public function block_head($context, array $blocks = array())
    {
        // line 5
        echo "            <title>";
        $this->displayBlock('title', $context, $blocks);
        echo " - My Webpage</title>
            
            <script src=\"http://code.jquery.com/jquery-2.1.0.min.js\" type=\"text/javascript\" charset=\"utf-8\"></script>    
            <link rel=\"stylesheet\" href=\"http://cdn.webix.io/edge/webix.css\" type=\"text/css\" media=\"screen\" charset=\"utf-8\">
            <script src=\"http://cdn.webix.io/edge/webix.js\" type=\"text/javascript\" charset=\"utf-8\"></script>    
            
            ";
        // line 11
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "af41074_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_af41074_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/af41074_part_1_app_1.js");
            // line 12
            echo "                <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
            ";
        } else {
            // asset "af41074"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_af41074") : $this->env->getExtension('assets')->getAssetUrl("_controller/js/af41074.js");
            echo "                <script type=\"text/javascript\" src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
            ";
        }
        unset($context["asset_url"]);
        // line 14
        echo "            
            ";
        // line 15
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "30ba473_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_30ba473_0") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/30ba473_part_1_style_1.css");
            // line 16
            echo "                 <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
        } else {
            // asset "30ba473"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_30ba473") : $this->env->getExtension('assets')->getAssetUrl("_controller/css/30ba473.css");
            echo "                 <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
            ";
        }
        unset($context["asset_url"]);
        // line 18
        echo "
        ";
    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
    }

    // line 22
    public function block_content($context, array $blocks = array())
    {
    }

    // line 24
    public function block_footer($context, array $blocks = array())
    {
        // line 25
        echo "                &copy; Copyright 2014 by Matthew Burgess.
            ";
    }

    public function getTemplateName()
    {
        return "HypertdAddressbookBundle:Base:base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  117 => 25,  114 => 24,  109 => 22,  104 => 5,  99 => 18,  85 => 16,  81 => 15,  78 => 14,  64 => 12,  60 => 11,  50 => 5,  47 => 4,  41 => 27,  39 => 24,  36 => 23,  34 => 22,  30 => 20,  28 => 4,  23 => 1,);
    }
}
