<?php

// AcmeDemoBundle:Welcome:index.html.twig
return array (
);
