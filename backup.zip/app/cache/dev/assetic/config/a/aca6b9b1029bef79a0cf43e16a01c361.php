<?php

// SensioDistributionBundle:Configurator/Step:secret.html.twig
return array (
);
