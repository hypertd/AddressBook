<?php

// SecurityBundle:Collector:security.html.twig
return array (
);
