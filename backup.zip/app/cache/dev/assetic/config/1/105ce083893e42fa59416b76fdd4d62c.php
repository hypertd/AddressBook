<?php

// TwigBundle:Exception:error.atom.twig
return array (
);
