<?php

// AcmeDemoBundle:Secured:helloadmin.html.twig
return array (
);
