<?php

// AcmeDemoBundle:Secured:hello.html.twig
return array (
);
