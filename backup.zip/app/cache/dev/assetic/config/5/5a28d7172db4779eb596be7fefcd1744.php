<?php

// HypertdAddressbookBundle:Base:base.html.twig
return array (
  'af41074' => 
  array (
    0 => 
    array (
      0 => '@HypertdAddressbookBundle/Resources/public/js/*',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/af41074.js',
      'name' => 'af41074',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '30ba473' => 
  array (
    0 => 
    array (
      0 => 'bundles/hypertdaddressbook/css/*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/30ba473.css',
      'name' => '30ba473',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
