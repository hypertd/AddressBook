<?php

// WebProfilerBundle:Profiler:admin.html.twig
return array (
);
