<?php

// WebProfilerBundle:Profiler:body.css.twig
return array (
);
