<?php

// SensioDistributionBundle:Configurator:check.html.twig
return array (
);
