<?php

// WebProfilerBundle:Collector:exception.css.twig
return array (
);
