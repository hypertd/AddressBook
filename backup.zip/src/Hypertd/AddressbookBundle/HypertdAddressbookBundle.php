<?php

namespace Hypertd\AddressbookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HypertdAddressbookBundle extends Bundle
{
}
